# ClearPath

A free, privacy-first web app that helps people in financial crisis find fair
alternatives to predatory loans — nonprofit lenders, government assistance,
community funds, employer advances, faith-based aid, and utility hardship plans.

> You shouldn't pay $500 in fees to borrow $300.

---

## Stack

- **Next.js 15** (App Router, Server + Client components)
- **TypeScript** strict mode
- **Tailwind CSS 3** with design tokens
- **lucide-react** icons
- **Plausible** (optional) for privacy-first analytics
- Zero database required for v1 — programs live in `src/data/programs.ts`

---

## Quick start

```bash
# 1. Install dependencies
npm install

# 2. Set up local env (optional — defaults work)
cp .env.example .env.local

# 3. Run the dev server
npm run dev

# Open http://localhost:3000
```

That's it. No database setup. No external services required for local dev.

---

## Available scripts

| Command | What it does |
|---|---|
| `npm run dev` | Start the dev server on port 3000 |
| `npm run build` | Production build |
| `npm start` | Run the production build locally |
| `npm run lint` | ESLint |
| `npm run typecheck` | TypeScript check (no emit) |

---

## Project structure

```
clearpath-app/
├── src/
│   ├── app/                      ← routes (App Router)
│   │   ├── layout.tsx            ← root layout, fonts, metadata, analytics
│   │   ├── page.tsx              ← landing page (composed of sections)
│   │   ├── globals.css           ← base styles + Tailwind layers
│   │   ├── quiz/page.tsx         ← 5-question matching flow
│   │   ├── results/page.tsx      ← matched programs
│   │   ├── privacy/page.tsx      ← privacy policy
│   │   ├── terms/page.tsx        ← terms of service
│   │   ├── accessibility/page.tsx
│   │   ├── not-found.tsx         ← 404
│   │   ├── sitemap.ts            ← /sitemap.xml
│   │   ├── robots.ts             ← /robots.txt
│   │   └── api/match/route.ts    ← matching API endpoint
│   │
│   ├── components/
│   │   ├── sections/             ← landing-page sections (1 per file)
│   │   │   ├── Header.tsx
│   │   │   ├── Hero.tsx
│   │   │   ├── TrustStrip.tsx
│   │   │   ├── Stats.tsx
│   │   │   ├── HowItWorks.tsx
│   │   │   ├── Sources.tsx
│   │   │   ├── Testimonial.tsx
│   │   │   ├── About.tsx
│   │   │   ├── FAQ.tsx
│   │   │   ├── ClosingCTA.tsx
│   │   │   ├── Footer.tsx
│   │   │   └── LegalPage.tsx     ← shared layout for legal pages
│   │   └── ui/                   ← reusable primitives
│   │       ├── Button.tsx
│   │       ├── Container.tsx
│   │       ├── Logo.tsx
│   │       ├── SectionLabel.tsx
│   │       └── SerifHeading.tsx
│   │
│   ├── features/                 ← feature-scoped logic
│   │   ├── quiz/QuizFlow.tsx
│   │   ├── results/ResultsView.tsx
│   │   └── matching/
│   │       ├── match.ts          ← pure matching function
│   │       └── zip-to-state.ts   ← ZIP → US state lookup
│   │
│   ├── content/                  ← all user-facing copy
│   │   ├── landing.ts
│   │   ├── faq.ts
│   │   └── legal.ts
│   │
│   ├── data/
│   │   └── programs.ts           ← seed program database
│   │
│   ├── lib/
│   │   ├── tokens.ts             ← design tokens (single source of truth)
│   │   ├── cn.ts                 ← className combiner
│   │   └── analytics.ts          ← Plausible event helper
│   │
│   └── types/
│       └── program.ts            ← shared domain types
│
├── package.json
├── next.config.mjs
├── tailwind.config.ts
├── tsconfig.json
├── postcss.config.mjs
├── .env.example
└── README.md
```

---

## Architecture rules (read before editing)

1. **No hex colors in components.** Every color comes from `src/lib/tokens.ts`
   via Tailwind's `bg`, `text`, `border` etc. classes.
2. **No hardcoded strings in JSX.** All user-facing copy lives in `src/content/`.
3. **Sections are dumb.** Components in `components/sections/` take no props
   beyond what's in `content/`. No data fetching inside.
4. **Features own their stack.** Each folder in `features/` has its own
   components, hooks, server logic, and types. Features never import each other.
5. **Server / client boundary is explicit.** Files that need browser APIs start
   with `"use client"`. Everything else is a Server Component by default.

---

## Privacy & data principles

These are product principles, not legal boilerplate. The code reflects them:

- **No user accounts.** No registration, no login, no passwords.
- **No PII collected.** No name, email, SSN, credit pull, IP logging for tracking.
- **Session-only state.** Quiz answers live in `sessionStorage`. Closed tab = gone.
- **No third-party trackers.** Optional Plausible analytics is cookieless and
  fingerprint-free. Disable by leaving `NEXT_PUBLIC_PLAUSIBLE_DOMAIN` unset.
- **No data sales, no referral fees.** Promised in the footer, enforced by
  the absence of any code that could enable them.

---

## Updating the program database

Today the program list is a TypeScript array in `src/data/programs.ts`.
That works for v1 (a few hundred programs, edited via PR).

Before scaling, migrate to a real database:

1. Add Postgres (Vercel Postgres, Supabase, or Neon).
2. Define a `programs` table mirroring the `Program` type.
3. Replace the import in `src/features/matching/match.ts` with a DB query.
4. Build a small admin UI for ops to add / verify / disable programs.
5. Add a verification workflow: every program re-checked quarterly.

The matching logic itself (`match.ts`) is pure and won't need to change.

---

## Deploying to Vercel

```bash
# Push to GitHub
git init
git add .
git commit -m "feat: initial production build"
git branch -M main
git remote add origin git@github.com:YOUR_ORG/clearpath.git
git push -u origin main

# Then on vercel.com:
#  1. New Project → import the GitHub repo
#  2. Framework preset: Next.js (auto-detected)
#  3. Add env vars from .env.example
#  4. Deploy
```

A fresh Vercel deploy takes about 90 seconds. The first build will hit
~60 KB of JS on the landing route — well under typical performance budgets.

---

## Roadmap (intentionally short)

- [ ] Replace the seed program list with a real database + admin tool
- [ ] Add a "share these results" link (no PII, just a query-string snapshot)
- [ ] Multilingual support (Spanish first)
- [ ] Optional saved-results email (opt-in only, double-confirmed)
- [ ] State-by-state coverage page

We are deliberately not adding: user accounts, social login, gamification,
push notifications, ad networks, affiliate links, or any data resale.

---

## License

Source-available, non-commercial. See `LICENSE` (add before launch).

## Contact

`hello@clearpath.org`
