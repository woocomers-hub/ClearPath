import type { Metadata } from "next";
import { Footer } from "@/components/sections/Footer";
import { Header } from "@/components/sections/Header";
import { ResultsView } from "@/features/results/ResultsView";

export const metadata: Metadata = {
  title: "Your matches",
  robots: { index: false, follow: false },
};

export default function ResultsPage() {
  return (
    <>
      <Header />
      <main>
        <ResultsView />
      </main>
      <Footer />
    </>
  );
}
