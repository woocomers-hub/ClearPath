import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "https://clearpath.org";
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/results", "/api/"] }],
    sitemap: `${base}/sitemap.xml`,
  };
}
