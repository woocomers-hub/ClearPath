import { Footer } from "@/components/sections/Footer";
import { Header } from "@/components/sections/Header";
import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";

export default function NotFound() {
  return (
    <>
      <Header />
      <main>
        <Container size="narrow" className="py-32 text-center">
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-accent">
            404
          </p>
          <h1 className="font-serif text-4xl font-medium leading-tight tracking-tight text-text md:text-5xl">
            We couldn't find that page.
          </h1>
          <p className="mt-4 text-muted">
            The link may have moved. You can head back home or start the matching
            quiz directly.
          </p>
          <div className="mt-8 flex flex-col items-center gap-3">
            <Button href="/quiz" withArrow>
              Find a Better Option
            </Button>
            <a
              href="/"
              className="text-sm text-subtle underline-offset-4 hover:text-text hover:underline"
            >
              Back to home
            </a>
          </div>
        </Container>
      </main>
      <Footer />
    </>
  );
}
