import type { Metadata } from "next";
import { Footer } from "@/components/sections/Footer";
import { Header } from "@/components/sections/Header";
import { LegalPage } from "@/components/sections/LegalPage";
import { privacyPolicy } from "@/content/legal";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "ClearPath collects no PII, stores no session data, and never sells user information.",
};

export default function PrivacyPage() {
  return (
    <>
      <Header />
      <main>
        <LegalPage {...privacyPolicy} />
      </main>
      <Footer />
    </>
  );
}
