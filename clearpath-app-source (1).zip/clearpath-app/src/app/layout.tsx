import type { Metadata, Viewport } from "next";
import Script from "next/script";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "https://clearpath.org";
const plausibleDomain = process.env.NEXT_PUBLIC_PLAUSIBLE_DOMAIN;

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "ClearPath — Find a fair financial alternative in 60 seconds",
    template: "%s · ClearPath",
  },
  description:
    "Free, private, no signup. ClearPath finds you nonprofit lenders, paycheck advances, utility assistance, and community funds in your ZIP code.",
  keywords: [
    "payday loan alternatives",
    "nonprofit lender",
    "emergency financial help",
    "CDFI",
    "utility assistance",
    "community fund",
  ],
  authors: [{ name: "ClearPath PBC" }],
  openGraph: {
    type: "website",
    title: "ClearPath — Find a fair financial alternative in 60 seconds",
    description:
      "You shouldn't pay $500 in fees to borrow $300. ClearPath finds free, local alternatives to predatory loans.",
    url: siteUrl,
    siteName: "ClearPath",
  },
  twitter: {
    card: "summary_large_image",
    title: "ClearPath — Find a fair financial alternative in 60 seconds",
    description:
      "Free, private, no signup. Real alternatives to predatory loans in 60 seconds.",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#0B0F14",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
        {plausibleDomain && (
          <Script
            defer
            data-domain={plausibleDomain}
            src="https://plausible.io/js/script.js"
            strategy="afterInteractive"
          />
        )}
      </body>
    </html>
  );
}
