import { type NextRequest, NextResponse } from "next/server";
import { matchPrograms } from "@/features/matching/match";
import type { QuizAnswers } from "@/types/program";

const validNeeds = new Set([
  "rent",
  "utilities",
  "food",
  "medical",
  "car_repair",
  "other",
]);
const validAmounts = new Set(["<200", "200-500", "500-1000", "1000+"]);
const validUrgency = new Set(["today", "this_week", "this_month"]);

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Invalid body" }, { status: 400 });
  }

  const b = body as Record<string, unknown>;

  const zip = typeof b.zip === "string" ? b.zip.trim() : "";
  const need = typeof b.need === "string" ? b.need : "";
  const amountNeeded = typeof b.amountNeeded === "string" ? b.amountNeeded : "";
  const urgency = typeof b.urgency === "string" ? b.urgency : "";
  const hasIncome = typeof b.hasIncome === "boolean" ? b.hasIncome : null;

  if (!/^\d{5}$/.test(zip)) {
    return NextResponse.json({ error: "Invalid ZIP code" }, { status: 400 });
  }
  if (!validNeeds.has(need)) {
    return NextResponse.json({ error: "Invalid need" }, { status: 400 });
  }
  if (!validAmounts.has(amountNeeded)) {
    return NextResponse.json({ error: "Invalid amount" }, { status: 400 });
  }
  if (!validUrgency.has(urgency)) {
    return NextResponse.json({ error: "Invalid urgency" }, { status: 400 });
  }
  if (hasIncome === null) {
    return NextResponse.json({ error: "Invalid income field" }, { status: 400 });
  }

  const answers: QuizAnswers = {
    zip,
    need: need as QuizAnswers["need"],
    amountNeeded: amountNeeded as QuizAnswers["amountNeeded"],
    urgency: urgency as QuizAnswers["urgency"],
    hasIncome,
  };

  const result = matchPrograms(answers);

  return NextResponse.json(result, {
    headers: {
      // Never cache — this is per-user data
      "Cache-Control": "no-store, no-cache, must-revalidate",
    },
  });
}
