import type { Metadata } from "next";
import { Footer } from "@/components/sections/Footer";
import { Header } from "@/components/sections/Header";
import { LegalPage } from "@/components/sections/LegalPage";
import { accessibilityStatement } from "@/content/legal";

export const metadata: Metadata = {
  title: "Accessibility",
};

export default function AccessibilityPage() {
  return (
    <>
      <Header />
      <main>
        <LegalPage {...accessibilityStatement} />
      </main>
      <Footer />
    </>
  );
}
