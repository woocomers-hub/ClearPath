import { About } from "@/components/sections/About";
import { ClosingCTA } from "@/components/sections/ClosingCTA";
import { FAQ } from "@/components/sections/FAQ";
import { Footer } from "@/components/sections/Footer";
import { Header } from "@/components/sections/Header";
import { Hero } from "@/components/sections/Hero";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { Sources } from "@/components/sections/Sources";
import { Stats } from "@/components/sections/Stats";
import { Testimonial } from "@/components/sections/Testimonial";
import { TrustStrip } from "@/components/sections/TrustStrip";

export default function HomePage() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <TrustStrip />
        <Stats />
        <HowItWorks />
        <Sources />
        <Testimonial />
        <About />
        <FAQ />
        <ClosingCTA />
      </main>
      <Footer />
    </>
  );
}
