import type { Metadata } from "next";
import { Footer } from "@/components/sections/Footer";
import { Header } from "@/components/sections/Header";
import { LegalPage } from "@/components/sections/LegalPage";
import { termsOfService } from "@/content/legal";

export const metadata: Metadata = {
  title: "Terms of Service",
};

export default function TermsPage() {
  return (
    <>
      <Header />
      <main>
        <LegalPage {...termsOfService} />
      </main>
      <Footer />
    </>
  );
}
