import type { Metadata } from "next";
import { Footer } from "@/components/sections/Footer";
import { Header } from "@/components/sections/Header";
import { QuizFlow } from "@/features/quiz/QuizFlow";

export const metadata: Metadata = {
  title: "Find help",
  description:
    "Five quick questions and ClearPath will match you to fair financial-help programs in your area. No signup, no data kept.",
};

export default function QuizPage() {
  return (
    <>
      <Header />
      <main>
        <section className="mx-auto px-6 py-16 md:py-24">
          <QuizFlow />
        </section>
      </main>
      <Footer />
    </>
  );
}
