/**
 * Seed database of vetted programs.
 *
 * IMPORTANT: This is a curated starter set. In production:
 *   1. Move this to a real database (Postgres) so it can be edited by ops.
 *   2. Add a verification workflow — every program re-checked quarterly.
 *   3. Track program status (active / paused / waitlist) per ZIP region.
 *
 * Categories included today:
 *   - National CDFIs and nonprofit lenders
 *   - Federal assistance programs (LIHEAP, SNAP, etc.)
 *   - Major faith-based aid networks
 *   - Major community funds (United Way, 211)
 *   - Earned-wage access platforms
 *   - Utility hardship programs (sample states)
 */

import type { Program } from "@/types/program";

export const programs: readonly Program[] = [
  /* ---------------- National nonprofit lenders / CDFIs ---------------- */
  {
    id: "lendingcircles-miss-asset-fund",
    name: "Mission Asset Fund — Lending Circles",
    category: "cdfi",
    description:
      "Zero-interest social loans up to $2,400, with credit-building reporting to all three bureaus.",
    helpsWith: ["rent", "utilities", "car_repair", "medical", "other"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://missionassetfund.org/lending-circles/",
      label: "Visit Mission Asset Fund",
    },
    eligibility: "Open to all US residents. No minimum credit score.",
  },
  {
    id: "self-help-credit-union",
    name: "Self-Help Federal Credit Union",
    category: "credit_union",
    description:
      "Small-dollar personal loans starting at $300, capped at fair APRs. Membership is free.",
    helpsWith: ["rent", "utilities", "car_repair", "medical", "food", "other"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.self-helpfcu.org/personal/borrow/personal-loans",
      label: "Apply at Self-Help FCU",
    },
    eligibility: "US residents. Membership free; soft credit pull only.",
  },
  {
    id: "capital-good-fund",
    name: "Capital Good Fund",
    category: "cdfi",
    description:
      "Crisis loans of $300–$1,500 at low fixed APR. Funds disbursed within 1 business day.",
    helpsWith: ["rent", "utilities", "car_repair", "medical", "other"],
    coverage: ["RI", "MA", "DE", "FL", "IL", "TX", "GA", "NC", "VA", "PA", "CO"],
    action: {
      type: "url",
      value: "https://capitalgoodfund.org/",
      label: "Apply at Capital Good Fund",
    },
    eligibility: "Income-based; no credit minimum.",
  },

  /* ---------------- Federal / government assistance ---------------- */
  {
    id: "liheap",
    name: "LIHEAP — Energy Assistance",
    category: "government",
    description:
      "Federal program that helps low-income households pay heating, cooling, and utility bills.",
    helpsWith: ["utilities"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.acf.hhs.gov/ocs/programs/liheap",
      label: "Find your state's LIHEAP office",
    },
    eligibility: "Income limits vary by state. Many households qualify.",
  },
  {
    id: "snap",
    name: "SNAP (Food Stamps)",
    category: "government",
    description:
      "Monthly grocery benefits delivered on an EBT card. Apply once, receive every month you qualify.",
    helpsWith: ["food"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.fns.usda.gov/snap/state-directory",
      label: "Apply for SNAP in your state",
    },
    eligibility: "Income- and household-size based.",
  },
  {
    id: "tanf",
    name: "TANF — Temporary Cash Assistance",
    category: "government",
    description:
      "Monthly cash assistance for families with children, plus help finding work.",
    helpsWith: ["rent", "utilities", "food", "other"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.acf.hhs.gov/ofa/map/about/help-families",
      label: "Find your state's TANF office",
    },
    eligibility: "Families with children; income-based.",
  },
  {
    id: "211",
    name: "211 — United Way Resource Line",
    category: "community_fund",
    description:
      "Free, 24/7 phone line that connects you to local emergency assistance — rent, food, utilities, shelter.",
    helpsWith: ["rent", "utilities", "food", "medical", "other"],
    coverage: "national",
    action: {
      type: "phone",
      value: "211",
      label: "Call 2-1-1",
    },
    eligibility: "Open to anyone in the US and Canada.",
  },

  /* ---------------- Faith-based aid networks ---------------- */
  {
    id: "catholic-charities",
    name: "Catholic Charities USA",
    category: "faith_based",
    description:
      "Emergency rent, utility, and food assistance through 168 local agencies. No religious requirement.",
    helpsWith: ["rent", "utilities", "food", "medical"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.catholiccharitiesusa.org/find-help/",
      label: "Find a local Catholic Charities",
    },
    eligibility: "Open to all faiths and backgrounds.",
  },
  {
    id: "salvation-army",
    name: "The Salvation Army",
    category: "faith_based",
    description:
      "Emergency assistance for rent, utilities, food, clothing, and shelter.",
    helpsWith: ["rent", "utilities", "food", "other"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.salvationarmyusa.org/usn/ways-we-help/",
      label: "Find a local Salvation Army",
    },
    eligibility: "Open to all.",
  },
  {
    id: "jewish-family-services",
    name: "Jewish Family Services",
    category: "faith_based",
    description:
      "Local emergency funds, food pantries, and case management. Open to anyone in need regardless of faith.",
    helpsWith: ["rent", "utilities", "food", "medical", "other"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.networkofjewishhumanservices.org/",
      label: "Find your local JFS",
    },
    eligibility: "Open to all.",
  },

  /* ---------------- Earned-wage access ---------------- */
  {
    id: "payactiv",
    name: "PayActiv (through your employer)",
    category: "employer_advance",
    description:
      "If your employer offers PayActiv, you can access wages you've already earned — fee free or low fee.",
    helpsWith: ["rent", "utilities", "food", "car_repair", "medical", "other"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.payactiv.com/employees/",
      label: "Check if your employer offers PayActiv",
    },
    eligibility: "Available only through participating employers.",
  },
  {
    id: "dailypay",
    name: "DailyPay (through your employer)",
    category: "employer_advance",
    description:
      "Access your earned wages on demand. Funds typically available within minutes.",
    helpsWith: ["rent", "utilities", "food", "car_repair", "medical", "other"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.dailypay.com/",
      label: "Check if your employer offers DailyPay",
    },
    eligibility: "Available only through participating employers.",
  },

  /* ---------------- Medical ---------------- */
  {
    id: "rip-medical-debt",
    name: "Undue Medical Debt (RIP Medical Debt)",
    category: "community_fund",
    description:
      "A nonprofit that buys and forgives medical debt. Check eligibility for relief on existing bills.",
    helpsWith: ["medical"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://undueMedicalDebt.org/",
      label: "Visit Undue Medical Debt",
    },
    eligibility: "Income-based.",
  },
  {
    id: "healthwell",
    name: "HealthWell Foundation",
    category: "community_fund",
    description:
      "Grants for prescription copays and treatment costs for specific conditions.",
    helpsWith: ["medical"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.healthwellfoundation.org/",
      label: "Apply at HealthWell",
    },
    eligibility: "Diagnosis- and income-based.",
  },

  /* ---------------- Utility hardship plans ---------------- */
  {
    id: "ngrid-arrearage",
    name: "National Grid — Arrearage Forgiveness",
    category: "utility",
    description:
      "Pay your current bill on time and National Grid forgives a portion of past-due balance each month.",
    helpsWith: ["utilities"],
    coverage: ["NY", "MA", "RI"],
    action: {
      type: "url",
      value: "https://www.nationalgridus.com/",
      label: "Contact National Grid",
    },
  },
  {
    id: "duke-share",
    name: "Duke Energy — Customer Assistance",
    category: "utility",
    description:
      "Emergency utility-bill assistance, payment plans, and energy-cost help for Duke Energy customers.",
    helpsWith: ["utilities"],
    coverage: ["NC", "SC", "FL", "IN", "KY", "OH"],
    action: {
      type: "url",
      value: "https://www.duke-energy.com/community",
      label: "Get help from Duke Energy",
    },
  },

  /* ---------------- Car / transportation ---------------- */
  {
    id: "modest-needs",
    name: "Modest Needs Foundation",
    category: "community_fund",
    description:
      "Small emergency grants for working households facing a one-time crisis (car repair, medical co-pay, etc.).",
    helpsWith: ["car_repair", "medical", "rent", "utilities", "other"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.modestneeds.org/",
      label: "Apply at Modest Needs",
    },
    eligibility: "Working low-income households just above the poverty line.",
  },

  /* ---------------- Fallback / counseling ---------------- */
  {
    id: "nfcc",
    name: "National Foundation for Credit Counseling",
    category: "community_fund",
    description:
      "Free or low-cost credit counseling, debt management, and budget planning from accredited nonprofits.",
    helpsWith: ["other"],
    coverage: "national",
    action: {
      type: "url",
      value: "https://www.nfcc.org/",
      label: "Find a counselor",
    },
    eligibility: "Open to all.",
  },
] as const;

/** Always-show fallback resources when no direct match exists */
export const fallbackPrograms: readonly Program[] = programs.filter((p) =>
  ["211", "nfcc"].includes(p.id),
);
