/**
 * Legal page content. Plain language, ~8th-grade reading level.
 * IMPORTANT: have these reviewed by a qualified attorney before launch.
 */

const updated = "April 27, 2026";

export const privacyPolicy = {
  title: "Privacy Policy",
  updated,
  intro:
    "ClearPath exists because people in financial crisis deserve dignity. That starts with privacy. This page explains, in plain language, exactly what we do and don't do with your information.",
  sections: [
    {
      heading: "What we collect",
      body: [
        "When you use the matching tool, we collect only what's needed to find programs in your area: your ZIP code, the type of help you need, the amount, the urgency, and whether you currently have income.",
        "We do not ask for your name, email address, phone number, Social Security Number, date of birth, or any government-issued ID.",
      ],
    },
    {
      heading: "What we don't collect",
      body: [
        "We do not collect IP addresses for tracking purposes. We do not fingerprint your device. We do not pull your credit report. We do not access your bank account. We do not place advertising trackers on your device.",
      ],
    },
    {
      heading: "How long we keep it",
      body: [
        "Your answers exist only in your browser session. When you close the tab, they are gone. We do not store your quiz answers on our servers, and we do not log them.",
      ],
    },
    {
      heading: "Who we share it with",
      body: [
        "Nobody. We never sell, rent, license, or share your data with any third party — including the programs we recommend. When you click through to a partner program, that program may collect its own information under its own privacy policy.",
      ],
    },
    {
      heading: "Analytics",
      body: [
        "We use Plausible, a privacy-first analytics tool that does not use cookies, does not track individuals, and is fully GDPR/CCPA compliant. We see aggregate counts (how many people visited the FAQ page) but never individual sessions.",
      ],
    },
    {
      heading: "Your rights",
      body: [
        "Because we don't store personal data, there is nothing to access, export, or delete. If you have any privacy concern, email us at hello@clearpath.org and we will respond within 7 business days.",
      ],
    },
    {
      heading: "Contact",
      body: [
        "ClearPath PBC, 300 Mission St, San Francisco CA 94105. Email: hello@clearpath.org.",
      ],
    },
  ],
} as const;

export const termsOfService = {
  title: "Terms of Service",
  updated,
  intro:
    "These terms describe what ClearPath does, what we don't do, and the small set of rules for using the site.",
  sections: [
    {
      heading: "What ClearPath is",
      body: [
        "ClearPath is a free public-benefit information service. We help you discover financial-assistance programs and fair-rate lenders that may exist in your area. We are not a lender, a broker, a bank, or a credit counselor.",
      ],
    },
    {
      heading: "What ClearPath is not",
      body: [
        "ClearPath does not lend money. ClearPath does not guarantee that any program we list will accept you, fund you, or treat you fairly. Eligibility, terms, and approval are determined entirely by the program you contact.",
        "Information on this site is for general guidance only and is not legal, financial, or tax advice.",
      ],
    },
    {
      heading: "How to use the site",
      body: [
        "You agree to use ClearPath honestly and only for the purpose of finding help for yourself or someone you are assisting. You agree not to scrape the site, attempt to break it, or misuse the matching tool.",
      ],
    },
    {
      heading: "Third-party programs",
      body: [
        "Programs listed in your results are run by independent organizations. ClearPath does not endorse, control, or take responsibility for any third-party program's actions, decisions, or outcomes. Always read the terms of any program before applying.",
      ],
    },
    {
      heading: "No warranty",
      body: [
        "ClearPath is provided 'as is.' We do our best to keep the program database accurate and up to date, but we cannot guarantee that any specific program is currently funded, available, or accepting applicants.",
      ],
    },
    {
      heading: "Limitation of liability",
      body: [
        "To the fullest extent permitted by law, ClearPath PBC is not liable for any indirect, incidental, or consequential damages arising from your use of the site or any third-party program you discover through it.",
      ],
    },
    {
      heading: "Changes",
      body: [
        "We may update these terms occasionally. The 'Last updated' date at the top of this page reflects the most recent change. Continued use of the site after a change means you accept the updated terms.",
      ],
    },
    {
      heading: "Contact",
      body: [
        "Questions about these terms? Email hello@clearpath.org.",
      ],
    },
  ],
} as const;

export const accessibilityStatement = {
  title: "Accessibility Statement",
  updated,
  intro:
    "ClearPath is built for everyone — especially people in stressful situations who may be using assistive technology. We design and test against WCAG 2.2 Level AA.",
  sections: [
    {
      heading: "Our commitment",
      body: [
        "We believe accessibility is a baseline requirement, not a feature. Every page, button, and form on ClearPath is built to work with screen readers, keyboard navigation, and high-contrast displays.",
      ],
    },
    {
      heading: "What we do",
      body: [
        "Semantic HTML on every page. Visible keyboard focus on every interactive element. Color contrast that meets or exceeds WCAG AA on all text. Reduced-motion support for users who prefer less animation. Form labels and ARIA descriptions on every input.",
      ],
    },
    {
      heading: "Known limitations",
      body: [
        "We are continuously testing. If you find any page, control, or content that doesn't work for you with assistive technology, please tell us — it is a bug we will fix.",
      ],
    },
    {
      heading: "Reporting issues",
      body: [
        "Email accessibility@clearpath.org or hello@clearpath.org. We aim to respond within 5 business days.",
      ],
    },
  ],
} as const;
