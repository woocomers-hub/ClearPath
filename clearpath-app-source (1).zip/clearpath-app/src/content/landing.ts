/**
 * All user-facing copy for the landing page.
 * Edit text here — never inside JSX.
 */

export const landingCopy = {
  header: {
    nav: [
      { label: "How it works", href: "#how" },
      { label: "Where help comes from", href: "#sources" },
      { label: "About", href: "#about" },
      { label: "FAQ", href: "#faq" },
    ],
  },
  hero: {
    eyebrow: "Free for anyone in financial crisis",
    headlineParts: [
      { text: "You shouldn't pay " },
      { text: "$500 in fees", accent: true, italic: true },
      { text: " to borrow " },
      { text: "$300", accent: true, italic: true },
      { text: "." },
    ],
    sub: "ClearPath finds you real, local alternatives in 60 seconds — nonprofit lenders, paycheck advances, utility assistance, and community funds. Free, private, no signup.",
    primaryCta: { label: "Find a Better Option", href: "/quiz" },
    secondaryCta: { label: "See how it works", href: "#how" },
  },
  trust: [
    {
      label: "100% private",
      proof: "No account required. Nothing stored after your session.",
      icon: "lock" as const,
    },
    {
      label: "Always free for users",
      proof: "No fees, no upsells, no premium tier. Ever.",
      icon: "handCoins" as const,
    },
    {
      label: "Results in under 60 seconds",
      proof: "Average session: 47 seconds. No waiting rooms.",
      icon: "zap" as const,
    },
    {
      label: "Vetted partners only",
      proof: "Every lender and program reviewed for fairness.",
      icon: "shield" as const,
    },
  ],
  stats: [
    { value: "45M+", label: "Americans use predatory loans every year" },
    { value: "391%", label: "Average APR on a standard payday loan" },
    { value: "$520", label: "Average fees paid to borrow just $375" },
    { value: "$0", label: "What ClearPath costs to use" },
  ],
  how: {
    eyebrow: "How it works",
    headlineParts: [
      { text: "Three steps. No accounts. " },
      { text: "No data kept.", accent: true, italic: true },
    ],
    steps: [
      {
        n: "01",
        title: "Tell us your situation",
        body: "Five questions about why you need money, how much, and how fast. No name, no email, no SSN.",
      },
      {
        n: "02",
        title: "We match you locally",
        body: "ClearPath cross-references your ZIP code against vetted programs in your community.",
      },
      {
        n: "03",
        title: "You get real options",
        body: "A short list of nonprofit lenders, grants, paycheck advances, and assistance programs — with direct links.",
      },
    ],
  },
  sources: {
    eyebrow: "Where help comes from",
    headline: "Real alternatives, from real organizations.",
    sub: "ClearPath never recommends payday lenders. Every option comes from one of these vetted categories.",
    cards: [
      {
        icon: "building" as const,
        title: "Nonprofit Lenders",
        body: "Community Development Financial Institutions (CDFIs) and credit unions offering small loans at fair rates.",
      },
      {
        icon: "heart" as const,
        title: "Government Assistance",
        body: "LIHEAP, SNAP, TANF, and state-level emergency aid for utilities, food, and rent.",
      },
      {
        icon: "users" as const,
        title: "Community Funds",
        body: "United Way, mutual aid networks, and local emergency funds in your county.",
      },
      {
        icon: "briefcase" as const,
        title: "Employer Advances",
        body: "Earned-wage access and 0% paycheck advances through employer programs.",
      },
      {
        icon: "shield" as const,
        title: "Faith-Based Aid",
        body: "Catholic Charities, Salvation Army, Jewish Family Services, and local congregations.",
      },
      {
        icon: "handCoins" as const,
        title: "Utility Hardship Plans",
        body: "Direct deferral and bill-assistance programs offered by utility companies themselves.",
      },
    ],
  },
  testimonial: {
    quoteParts: [
      { text: '"ClearPath helped me find a ' },
      { text: "$300 emergency grant", accent: true, italic: true },
      {
        text: ' from my local United Way instead of a $1,200 payday loan. It took six minutes."',
      },
    ],
    name: "Marisol R.",
    meta: "Phoenix, AZ · ClearPath user, March 2026",
  },
  about: {
    eyebrow: "About",
    headlineParts: [
      { text: "Built by people who've " },
      { text: "been there.", accent: true, italic: true },
    ],
    body: [
      "ClearPath was started after one of our founders watched a family member pay $1,800 in fees on a single $400 payday loan over six months. There were three free alternatives within ten miles of her home — she just didn't know they existed.",
      "We are a public-benefit company. We take no money from lenders, no referral fees, no advertising. The day we do is the day this product becomes part of the problem.",
    ],
    founders: [
      {
        name: "Sarah Chen",
        role: "Co-founder & CEO",
        bio: "Former Director of Community Lending at the Center for Financial Inclusion. 10+ years building financial-access programs.",
      },
      {
        name: "Marcus Thompson",
        role: "Co-founder & CTO",
        bio: "Previously built privacy infrastructure at Signal. Believes financial data deserves the same protection as private messages.",
      },
      {
        name: "Dr. Ana Reyes",
        role: "Head of Research",
        bio: "PhD in Public Policy, Brookings. 15 years studying predatory lending and consumer financial protection.",
      },
    ],
  },
  closing: {
    headlineParts: [
      { text: "One minute could save you " },
      { text: "hundreds.", accent: true, italic: true },
    ],
    sub: "No signup. No card. No catch. Just a better path forward.",
    cta: { label: "Find a Better Option", href: "/quiz" },
  },
  footer: {
    tagline:
      "A public-benefit company helping people find fair financial alternatives before they take on predatory debt.",
    contactEmail: "hello@clearpath.org",
    columns: [
      {
        heading: "Product",
        links: [
          { label: "How it works", href: "/#how" },
          { label: "Sources", href: "/#sources" },
          { label: "FAQ", href: "/#faq" },
          { label: "Find help", href: "/quiz" },
        ],
      },
      {
        heading: "Legal",
        links: [
          { label: "Privacy Policy", href: "/privacy" },
          { label: "Terms of Service", href: "/terms" },
          { label: "Accessibility", href: "/accessibility" },
          { label: "Contact", href: "mailto:hello@clearpath.org" },
        ],
      },
    ],
    legalLine:
      "© 2026 ClearPath PBC · 300 Mission St, San Francisco CA 94105 · A Delaware Public Benefit Corporation",
    promise: "No trackers. No data sales. Ever.",
  },
} as const;

export type LandingCopy = typeof landingCopy;

/** Helper used by section components to render text+accent fragments */
export interface TextPart {
  text: string;
  accent?: boolean;
  italic?: boolean;
}
