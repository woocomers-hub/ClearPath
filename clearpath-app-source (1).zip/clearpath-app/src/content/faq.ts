/**
 * FAQ items shown on the landing page.
 * Order matters — most-asked first.
 */

export interface FaqEntry {
  q: string;
  a: string;
}

export const faqEntries: readonly FaqEntry[] = [
  {
    q: "Is this really free?",
    a: "Yes. Always. ClearPath takes no money from users and no referral fees from lenders. We're funded by foundation grants and individual donations.",
  },
  {
    q: "Will using ClearPath hurt my credit?",
    a: "No. We don't pull your credit. We don't ask for your SSN. We don't share anything with credit bureaus. Period.",
  },
  {
    q: "Do you sell my data?",
    a: "No. We don't store your session data after you close the page. We don't have user accounts. We use privacy-first analytics that never fingerprint you.",
  },
  {
    q: "What if no alternative exists for me?",
    a: "We'll tell you honestly. We'd rather say 'we couldn't find a better option this time' than send you to a predatory lender. We'll also point you toward financial counseling resources.",
  },
  {
    q: "What states do you cover?",
    a: "All 50 US states plus DC. Coverage and program availability vary by ZIP code — we only show you what's actually available where you live.",
  },
];
