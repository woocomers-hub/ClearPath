import Link from "next/link";
import type { ReactNode } from "react";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/cn";

interface ButtonProps {
  href: string;
  children: ReactNode;
  variant?: "primary" | "secondary";
  withArrow?: boolean;
  className?: string;
  ariaLabel?: string;
}

export function Button({
  href,
  children,
  variant = "primary",
  withArrow = false,
  className,
  ariaLabel,
}: ButtonProps) {
  const base =
    "group inline-flex items-center justify-center gap-2.5 rounded-full px-7 py-4 text-[15px] font-semibold transition-all";

  const styles =
    variant === "primary"
      ? "bg-primary text-white shadow-cta hover:scale-[1.02]"
      : "border border-border bg-surface text-text hover:bg-surfaceAlt";

  const isExternal = href.startsWith("http") || href.startsWith("mailto:");

  const inner = (
    <>
      {children}
      {withArrow && (
        <ArrowRight
          className="h-4 w-4 transition-transform group-hover:translate-x-0.5"
          aria-hidden
        />
      )}
    </>
  );

  if (isExternal) {
    return (
      <a
        href={href}
        className={cn(base, styles, className)}
        aria-label={ariaLabel}
        target={href.startsWith("http") ? "_blank" : undefined}
        rel={href.startsWith("http") ? "noopener noreferrer" : undefined}
      >
        {inner}
      </a>
    );
  }

  return (
    <Link href={href} className={cn(base, styles, className)} aria-label={ariaLabel}>
      {inner}
    </Link>
  );
}
