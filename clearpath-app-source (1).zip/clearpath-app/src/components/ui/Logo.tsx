import Link from "next/link";
import { Shield } from "lucide-react";

export function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2.5" aria-label="ClearPath home">
      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
        <Shield className="h-4 w-4 text-white" strokeWidth={2.5} aria-hidden />
      </div>
      <span className="text-[17px] font-semibold tracking-tight text-text">
        ClearPath
      </span>
    </Link>
  );
}
