import type { ElementType } from "react";
import type { TextPart } from "@/content/landing";
import { cn } from "@/lib/cn";

interface SerifHeadingProps {
  parts: readonly TextPart[];
  as?: ElementType;
  className?: string;
}

/**
 * Renders headlines composed of text fragments with optional accent + italic
 * styling. Keeps the serif/italic accent pattern consistent across the app.
 */
export function SerifHeading({ parts, as: Tag = "h2", className }: SerifHeadingProps) {
  return (
    <Tag
      className={cn(
        "font-serif font-medium leading-tight tracking-tight text-text",
        className,
      )}
    >
      {parts.map((part, i) => {
        if (part.accent && part.italic) {
          return (
            <em key={i} className="text-accent not-italic">
              <i>{part.text}</i>
            </em>
          );
        }
        if (part.accent) {
          return (
            <span key={i} className="text-accent">
              {part.text}
            </span>
          );
        }
        if (part.italic) {
          return <em key={i}>{part.text}</em>;
        }
        return <span key={i}>{part.text}</span>;
      })}
    </Tag>
  );
}
