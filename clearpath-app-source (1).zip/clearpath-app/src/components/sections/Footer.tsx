import { CheckCircle2, Mail } from "lucide-react";
import Link from "next/link";
import { Container } from "@/components/ui/Container";
import { Logo } from "@/components/ui/Logo";
import { landingCopy } from "@/content/landing";

export function Footer() {
  const { footer } = landingCopy;

  return (
    <footer className="border-t border-border/60 bg-bg" aria-label="Site footer">
      <Container className="py-14">
        <div className="grid grid-cols-2 gap-10 md:grid-cols-4">
          <div className="col-span-2">
            <div className="mb-4">
              <Logo />
            </div>
            <p className="max-w-sm text-sm leading-relaxed text-subtle">
              {footer.tagline}
            </p>
            <a
              href={`mailto:${footer.contactEmail}`}
              className="mt-5 inline-flex items-center gap-2 text-xs text-subtle transition-colors hover:text-text"
            >
              <Mail className="h-3.5 w-3.5" aria-hidden />
              {footer.contactEmail}
            </a>
          </div>

          {footer.columns.map((col) => (
            <div key={col.heading}>
              <p className="mb-4 text-xs font-semibold uppercase tracking-wider text-muted">
                {col.heading}
              </p>
              <ul className="space-y-2.5 text-sm text-subtle">
                {col.links.map((link) => (
                  <li key={link.label}>
                    {link.href.startsWith("mailto:") ? (
                      <a href={link.href} className="transition-colors hover:text-text">
                        {link.label}
                      </a>
                    ) : (
                      <Link href={link.href} className="transition-colors hover:text-text">
                        {link.label}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-3 border-t border-border/60 pt-8 text-xs text-subtle md:flex-row md:items-center">
          <p>{footer.legalLine}</p>
          <p className="inline-flex items-center gap-1.5">
            <CheckCircle2 className="h-3.5 w-3.5 text-success" aria-hidden />
            {footer.promise}
          </p>
        </div>
      </Container>
    </footer>
  );
}
