import { Container } from "@/components/ui/Container";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { SerifHeading } from "@/components/ui/SerifHeading";
import { landingCopy } from "@/content/landing";

export function About() {
  const { about } = landingCopy;

  return (
    <section id="about" className="border-y border-border/60 bg-bg" aria-labelledby="about-heading">
      <Container className="py-24">
        <div className="grid grid-cols-1 gap-16 lg:grid-cols-2">
          <div>
            <SectionLabel>{about.eyebrow}</SectionLabel>
            <SerifHeading
              as="h2"
              parts={about.headlineParts}
              className="mb-6 text-4xl md:text-5xl"
            />
            {about.body.map((p, i) => (
              <p key={i} className="mb-4 leading-relaxed text-muted last:mb-0">
                {p}
              </p>
            ))}
          </div>

          <div className="space-y-5">
            {about.founders.map((f) => (
              <article key={f.name} className="rounded-xl border border-border bg-surface p-6">
                <div className="mb-3 flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-full bg-surfaceAlt text-sm font-semibold text-text">
                    {f.name.split(" ").map((s) => s[0]).slice(0, 2).join("")}
                  </div>
                  <div>
                    <p className="text-[15px] font-semibold text-text">{f.name}</p>
                    <p className="text-xs text-accent">{f.role}</p>
                  </div>
                </div>
                <p className="text-sm leading-relaxed text-muted">{f.bio}</p>
              </article>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
