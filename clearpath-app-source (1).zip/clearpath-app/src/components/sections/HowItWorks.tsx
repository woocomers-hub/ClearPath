import { Container } from "@/components/ui/Container";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { SerifHeading } from "@/components/ui/SerifHeading";
import { landingCopy } from "@/content/landing";

export function HowItWorks() {
  const { how } = landingCopy;

  return (
    <section id="how" aria-labelledby="how-heading">
      <Container className="py-24">
        <div className="mb-14 max-w-2xl">
          <SectionLabel>{how.eyebrow}</SectionLabel>
          <SerifHeading
            as="h2"
            parts={how.headlineParts}
            className="text-4xl md:text-5xl"
          />
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {how.steps.map((step) => (
            <article
              key={step.n}
              className="rounded-2xl border border-border bg-surface p-7"
            >
              <p className="mb-5 text-xs font-semibold tracking-[0.2em] text-primary">
                {step.n}
              </p>
              <h3 className="mb-2.5 text-lg font-semibold text-text">{step.title}</h3>
              <p className="text-sm leading-relaxed text-muted">{step.body}</p>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}
