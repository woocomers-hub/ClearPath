import { Container } from "@/components/ui/Container";

interface Section {
  heading: string;
  body: readonly string[];
}

interface LegalPageProps {
  title: string;
  updated: string;
  intro: string;
  sections: readonly Section[];
}

export function LegalPage({ title, updated, intro, sections }: LegalPageProps) {
  return (
    <Container size="narrow" className="py-20 md:py-24">
      <h1 className="font-serif text-4xl font-medium leading-tight tracking-tight text-text md:text-5xl">
        {title}
      </h1>
      <p className="mt-3 text-sm text-subtle">Last updated {updated}</p>
      <p className="mt-8 text-lg leading-relaxed text-muted">{intro}</p>

      <div className="mt-12 space-y-10">
        {sections.map((section) => (
          <section key={section.heading}>
            <h2 className="text-xl font-semibold text-text">{section.heading}</h2>
            {section.body.map((para, i) => (
              <p key={i} className="mt-3 leading-relaxed text-muted">
                {para}
              </p>
            ))}
          </section>
        ))}
      </div>
    </Container>
  );
}
