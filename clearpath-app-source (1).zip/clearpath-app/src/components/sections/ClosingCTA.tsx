import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { SerifHeading } from "@/components/ui/SerifHeading";
import { landingCopy } from "@/content/landing";

export function ClosingCTA() {
  const { closing } = landingCopy;

  return (
    <section className="border-t border-border/60 bg-bg" aria-label="Get started">
      <Container size="narrow" className="py-20 text-center">
        <SerifHeading
          as="h2"
          parts={closing.headlineParts}
          className="mb-5 text-4xl md:text-5xl"
        />
        <p className="mx-auto mb-10 max-w-xl text-muted">{closing.sub}</p>
        <Button href={closing.cta.href} withArrow>
          {closing.cta.label}
        </Button>
      </Container>
    </section>
  );
}
