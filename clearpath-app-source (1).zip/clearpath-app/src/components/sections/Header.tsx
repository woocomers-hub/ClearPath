import { Container } from "@/components/ui/Container";
import { Logo } from "@/components/ui/Logo";
import { landingCopy } from "@/content/landing";

export function Header() {
  return (
    <header className="w-full border-b border-border/60">
      <Container>
        <div className="flex items-center justify-between py-5">
          <Logo />
          <nav
            className="hidden items-center gap-8 text-sm text-muted md:flex"
            aria-label="Primary"
          >
            {landingCopy.header.nav.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="transition-colors hover:text-text"
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>
      </Container>
    </header>
  );
}
