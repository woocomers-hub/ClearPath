import { Quote } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SerifHeading } from "@/components/ui/SerifHeading";
import { landingCopy } from "@/content/landing";

export function Testimonial() {
  const { testimonial } = landingCopy;

  return (
    <section aria-label="What users say">
      <Container size="narrow" className="py-24">
        <figure className="rounded-2xl border border-border bg-surface p-10 md:p-14">
          <Quote className="mb-6 h-8 w-8 text-primary" aria-hidden />
          <blockquote>
            <SerifHeading
              as="p"
              parts={testimonial.quoteParts}
              className="mb-8 text-[26px] leading-[1.4] md:text-[30px]"
            />
          </blockquote>
          <figcaption className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-surfaceAlt text-sm font-semibold text-text">
              {testimonial.name.charAt(0)}
            </div>
            <div>
              <p className="text-sm font-semibold text-text">{testimonial.name}</p>
              <p className="text-xs text-subtle">{testimonial.meta}</p>
            </div>
          </figcaption>
        </figure>
      </Container>
    </section>
  );
}
