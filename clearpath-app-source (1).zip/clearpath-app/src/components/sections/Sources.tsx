import {
  Briefcase,
  Building2,
  HandCoins,
  HeartHandshake,
  Shield,
  Users,
} from "lucide-react";
import type { ReactNode } from "react";
import { Container } from "@/components/ui/Container";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { landingCopy } from "@/content/landing";

const iconMap: Record<string, ReactNode> = {
  building: <Building2 className="h-5 w-5" aria-hidden />,
  heart: <HeartHandshake className="h-5 w-5" aria-hidden />,
  users: <Users className="h-5 w-5" aria-hidden />,
  briefcase: <Briefcase className="h-5 w-5" aria-hidden />,
  shield: <Shield className="h-5 w-5" aria-hidden />,
  handCoins: <HandCoins className="h-5 w-5" aria-hidden />,
};

export function Sources() {
  const { sources } = landingCopy;

  return (
    <section
      id="sources"
      className="border-y border-border/60 bg-bg"
      aria-labelledby="sources-heading"
    >
      <Container className="py-24">
        <div className="mb-14 max-w-2xl">
          <SectionLabel>{sources.eyebrow}</SectionLabel>
          <h2
            id="sources-heading"
            className="font-serif text-4xl font-medium leading-tight tracking-tight text-text md:text-5xl"
          >
            {sources.headline}
          </h2>
          <p className="mt-4 text-muted">{sources.sub}</p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {sources.cards.map((card) => (
            <article
              key={card.title}
              className="rounded-xl border border-border bg-surface p-6 transition-colors hover:border-primary/40"
            >
              <div className="mb-4 inline-flex h-9 w-9 items-center justify-center rounded-lg bg-surfaceAlt text-accent">
                {iconMap[card.icon]}
              </div>
              <h3 className="mb-2 text-base font-semibold text-text">{card.title}</h3>
              <p className="text-sm leading-relaxed text-muted">{card.body}</p>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}
