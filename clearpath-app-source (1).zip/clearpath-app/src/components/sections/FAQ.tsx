"use client";

import { ChevronDown } from "lucide-react";
import { useState } from "react";
import { Container } from "@/components/ui/Container";
import { SectionLabel } from "@/components/ui/SectionLabel";
import { faqEntries } from "@/content/faq";

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" aria-labelledby="faq-heading">
      <Container size="narrow" className="py-24">
        <div className="mb-12">
          <SectionLabel>Frequently asked</SectionLabel>
          <h2
            id="faq-heading"
            className="font-serif text-4xl font-medium leading-tight tracking-tight text-text md:text-5xl"
          >
            Honest answers.
          </h2>
        </div>

        <div className="space-y-3">
          {faqEntries.map((entry, i) => {
            const isOpen = openIndex === i;
            return (
              <div
                key={entry.q}
                className="rounded-xl border border-border bg-surface transition-colors data-[open=true]:bg-surfaceAlt/60"
                data-open={isOpen}
              >
                <button
                  type="button"
                  onClick={() => setOpenIndex(isOpen ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
                  aria-expanded={isOpen}
                  aria-controls={`faq-panel-${i}`}
                >
                  <span className="text-base font-medium text-text">{entry.q}</span>
                  <ChevronDown
                    className={`h-4 w-4 shrink-0 text-muted transition-transform ${
                      isOpen ? "rotate-180" : ""
                    }`}
                    aria-hidden
                  />
                </button>
                {isOpen && (
                  <div id={`faq-panel-${i}`} className="px-6 pb-5 text-sm leading-relaxed text-muted">
                    {entry.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
