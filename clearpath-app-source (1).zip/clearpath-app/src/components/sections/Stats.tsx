import { landingCopy } from "@/content/landing";

export function Stats() {
  return (
    <section className="border-y border-border/60" aria-label="Why ClearPath exists">
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-px bg-border/60 md:grid-cols-4">
        {landingCopy.stats.map((stat) => (
          <div key={stat.value} className="bg-bg px-8 py-12">
            <p className="mb-3 font-serif text-5xl font-medium tracking-tight text-text md:text-6xl">
              {stat.value}
            </p>
            <p className="text-sm leading-snug text-muted">{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
