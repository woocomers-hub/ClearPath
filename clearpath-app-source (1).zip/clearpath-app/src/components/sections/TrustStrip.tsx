import { HandCoins, Info, Lock, Shield, Zap } from "lucide-react";
import type { ReactNode } from "react";
import { landingCopy } from "@/content/landing";

const iconMap: Record<string, ReactNode> = {
  lock: <Lock className="h-4 w-4" aria-hidden />,
  handCoins: <HandCoins className="h-4 w-4" aria-hidden />,
  zap: <Zap className="h-4 w-4" aria-hidden />,
  shield: <Shield className="h-4 w-4" aria-hidden />,
};

export function TrustStrip() {
  return (
    <div className="border-t border-border/60 bg-bg">
      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-px bg-border/60 sm:grid-cols-2 md:grid-cols-4">
        {landingCopy.trust.map((item) => (
          <div key={item.label} className="bg-bg px-6 py-6">
            <div className="flex items-start gap-3">
              <div className="mt-0.5 text-accent">{iconMap[item.icon]}</div>
              <div className="flex-1">
                <p className="text-sm font-medium text-text">{item.label}</p>
                <p className="mt-1 inline-flex items-center gap-1 text-xs text-subtle">
                  <Info className="h-3 w-3" aria-hidden />
                  {item.proof}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
