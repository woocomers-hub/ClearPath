import { HeartHandshake } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Container } from "@/components/ui/Container";
import { SerifHeading } from "@/components/ui/SerifHeading";
import { landingCopy } from "@/content/landing";

export function Hero() {
  const { hero } = landingCopy;

  return (
    <section className="relative overflow-hidden">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 0%, rgba(59,130,246,0.10), transparent 70%)",
        }}
      />

      <Container size="narrow" className="relative pt-24 pb-20 text-center">
        <div className="mb-8 inline-flex items-center gap-2 rounded-full border border-border bg-surface px-3.5 py-1.5">
          <HeartHandshake className="h-3.5 w-3.5 text-accent" aria-hidden />
          <span className="text-xs font-medium text-muted">{hero.eyebrow}</span>
        </div>

        <SerifHeading
          as="h1"
          parts={hero.headlineParts}
          className="mb-7 text-[44px] sm:text-[56px] md:text-[68px]"
        />

        <p className="mx-auto mb-12 max-w-2xl text-lg leading-relaxed text-muted">
          {hero.sub}
        </p>

        <div className="flex flex-col items-center gap-5">
          <Button href={hero.primaryCta.href} withArrow>
            {hero.primaryCta.label}
          </Button>
          <a
            href={hero.secondaryCta.href}
            className="text-sm text-subtle underline-offset-4 transition-colors hover:text-muted hover:underline"
          >
            {hero.secondaryCta.label}
          </a>
        </div>
      </Container>
    </section>
  );
}
