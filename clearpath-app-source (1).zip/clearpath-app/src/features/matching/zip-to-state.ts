/**
 * Quick ZIP → US state lookup using the first-3-digit ZCTA prefix ranges.
 * This is a starter implementation — accurate enough for filtering at the
 * state level. Replace with a proper ZIP-database lookup in production.
 */

const ranges: Array<[number, number, string]> = [
  [1000, 2799, "MA"],
  [2800, 2999, "RI"],
  [3000, 3899, "NH"],
  [3900, 4999, "ME"],
  [5000, 5999, "VT"],
  [6000, 6999, "CT"],
  [7000, 8999, "NJ"],
  [10000, 14999, "NY"],
  [15000, 19699, "PA"],
  [19700, 19999, "DE"],
  [20000, 20599, "DC"],
  [20600, 21999, "MD"],
  [22000, 24699, "VA"],
  [24700, 26899, "WV"],
  [27000, 28999, "NC"],
  [29000, 29999, "SC"],
  [30000, 31999, "GA"],
  [32000, 34999, "FL"],
  [35000, 36999, "AL"],
  [37000, 38599, "TN"],
  [38600, 39799, "MS"],
  [40000, 42799, "KY"],
  [43000, 45999, "OH"],
  [46000, 47999, "IN"],
  [48000, 49999, "MI"],
  [50000, 52999, "IA"],
  [53000, 54999, "WI"],
  [55000, 56799, "MN"],
  [57000, 57799, "SD"],
  [58000, 58899, "ND"],
  [59000, 59999, "MT"],
  [60000, 62999, "IL"],
  [63000, 65899, "MO"],
  [66000, 67999, "KS"],
  [68000, 69399, "NE"],
  [70000, 71499, "LA"],
  [71600, 72999, "AR"],
  [73000, 74999, "OK"],
  [75000, 79999, "TX"],
  [80000, 81699, "CO"],
  [82000, 83199, "WY"],
  [83200, 83899, "ID"],
  [84000, 84799, "UT"],
  [85000, 86599, "AZ"],
  [87000, 88499, "NM"],
  [88900, 89899, "NV"],
  [90000, 96199, "CA"],
  [96700, 96899, "HI"],
  [97000, 97999, "OR"],
  [98000, 99499, "WA"],
  [99500, 99999, "AK"],
];

export function stateFromZip(zip: string): string | null {
  const cleaned = zip.replace(/\D/g, "").slice(0, 5);
  if (cleaned.length !== 5) return null;
  const n = parseInt(cleaned, 10);
  for (const [lo, hi, state] of ranges) {
    if (n >= lo && n <= hi) return state;
  }
  return null;
}
