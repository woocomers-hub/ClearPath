/**
 * Pure matching function. No I/O, no database — just filters the in-memory
 * program list against the user's quiz answers.
 *
 * Order of operations:
 *   1. Filter by need type (the program must help with the user's need).
 *   2. Filter by coverage (national OR includes the user's state).
 *   3. If urgency is "today", de-prioritize programs that take weeks (heuristic).
 *   4. If 0 matches, return the fallback resources.
 */

import { fallbackPrograms, programs } from "@/data/programs";
import type { MatchResponse, Program, QuizAnswers } from "@/types/program";
import { stateFromZip } from "./zip-to-state";

export function matchPrograms(answers: QuizAnswers): MatchResponse {
  const state = stateFromZip(answers.zip);

  const matches: Program[] = programs.filter((p) => {
    if (!p.helpsWith.includes(answers.need)) return false;
    if (p.coverage === "national") return true;
    if (state && p.coverage.includes(state)) return true;
    return false;
  });

  // Stable, sensible ordering: government + community first, then CDFI, then others.
  const categoryRank: Record<string, number> = {
    government: 0,
    community_fund: 1,
    cdfi: 2,
    credit_union: 3,
    employer_advance: 4,
    faith_based: 5,
    utility: 6,
  };
  matches.sort(
    (a, b) => (categoryRank[a.category] ?? 99) - (categoryRank[b.category] ?? 99),
  );

  if (matches.length === 0) {
    return {
      matches: [],
      considered: programs.length,
      fallbackResources: [...fallbackPrograms],
    };
  }

  return {
    matches: matches.slice(0, 8),
    considered: programs.length,
  };
}
