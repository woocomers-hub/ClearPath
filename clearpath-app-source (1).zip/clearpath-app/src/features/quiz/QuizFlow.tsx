"use client";

import { ArrowLeft, ArrowRight } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { trackEvent } from "@/lib/analytics";
import type { NeedType, QuizAnswers } from "@/types/program";

interface QuizState {
  zip: string;
  need: NeedType | null;
  amountNeeded: QuizAnswers["amountNeeded"] | null;
  urgency: QuizAnswers["urgency"] | null;
  hasIncome: boolean | null;
}

const initialState: QuizState = {
  zip: "",
  need: null,
  amountNeeded: null,
  urgency: null,
  hasIncome: null,
};

const needOptions: Array<{ value: NeedType; label: string }> = [
  { value: "rent", label: "Rent or mortgage" },
  { value: "utilities", label: "Utility bill" },
  { value: "food", label: "Food or groceries" },
  { value: "medical", label: "Medical expense" },
  { value: "car_repair", label: "Car repair / transportation" },
  { value: "other", label: "Something else" },
];

const amountOptions: Array<{ value: QuizAnswers["amountNeeded"]; label: string }> = [
  { value: "<200", label: "Less than $200" },
  { value: "200-500", label: "$200 – $500" },
  { value: "500-1000", label: "$500 – $1,000" },
  { value: "1000+", label: "More than $1,000" },
];

const urgencyOptions: Array<{ value: QuizAnswers["urgency"]; label: string }> = [
  { value: "today", label: "Today" },
  { value: "this_week", label: "This week" },
  { value: "this_month", label: "Within the month" },
];

export function QuizFlow() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [state, setState] = useState<QuizState>(initialState);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const totalSteps = 5;

  const canAdvance = (): boolean => {
    switch (step) {
      case 0:
        return /^\d{5}$/.test(state.zip);
      case 1:
        return state.need !== null;
      case 2:
        return state.amountNeeded !== null;
      case 3:
        return state.urgency !== null;
      case 4:
        return state.hasIncome !== null;
      default:
        return false;
    }
  };

  const next = () => {
    if (!canAdvance()) return;
    trackEvent("quiz_step_complete", { step });
    if (step < totalSteps - 1) {
      setStep(step + 1);
    } else {
      submit();
    }
  };

  const back = () => {
    setError(null);
    if (step > 0) setStep(step - 1);
  };

  const submit = async () => {
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch("/api/match", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          zip: state.zip,
          need: state.need,
          amountNeeded: state.amountNeeded,
          urgency: state.urgency,
          hasIncome: state.hasIncome,
        }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      sessionStorage.setItem("clearpath:results", JSON.stringify(data));
      sessionStorage.setItem("clearpath:answers", JSON.stringify(state));
      trackEvent("quiz_complete", {
        need: state.need ?? "",
        urgency: state.urgency ?? "",
      });
      router.push("/results");
    } catch (e) {
      setError(
        "Something went wrong finding your matches. Please try again. If it keeps happening, email hello@clearpath.org.",
      );
      setSubmitting(false);
    }
  };

  return (
    <div className="mx-auto w-full max-w-xl">
      {/* Progress */}
      <div className="mb-10">
        <div className="mb-3 flex items-center justify-between text-xs text-subtle">
          <span>
            Step {step + 1} of {totalSteps}
          </span>
          <span>No signup. No data kept.</span>
        </div>
        <div className="h-1 w-full overflow-hidden rounded-full bg-surface">
          <div
            className="h-full rounded-full bg-primary transition-all duration-300"
            style={{ width: `${((step + 1) / totalSteps) * 100}%` }}
          />
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-surface p-8 md:p-10">
        {step === 0 && (
          <Question
            title="What's your ZIP code?"
            sub="We use it to find programs in your area. Nothing else."
          >
            <input
              type="text"
              inputMode="numeric"
              autoFocus
              maxLength={5}
              value={state.zip}
              onChange={(e) =>
                setState({ ...state, zip: e.target.value.replace(/\D/g, "") })
              }
              onKeyDown={(e) => e.key === "Enter" && canAdvance() && next()}
              placeholder="12345"
              aria-label="ZIP code"
              className="w-full rounded-xl border border-border bg-bg px-5 py-4 text-2xl tracking-wider text-text placeholder:text-subtle focus:border-primary focus:outline-none"
            />
          </Question>
        )}

        {step === 1 && (
          <Question
            title="What do you need help with?"
            sub="Pick the closest match. You can change this later."
          >
            <ChoiceGrid
              options={needOptions}
              value={state.need}
              onChange={(v) => setState({ ...state, need: v })}
            />
          </Question>
        )}

        {step === 2 && (
          <Question title="Roughly how much do you need?">
            <ChoiceGrid
              options={amountOptions}
              value={state.amountNeeded}
              onChange={(v) => setState({ ...state, amountNeeded: v })}
            />
          </Question>
        )}

        {step === 3 && (
          <Question title="How quickly do you need it?">
            <ChoiceGrid
              options={urgencyOptions}
              value={state.urgency}
              onChange={(v) => setState({ ...state, urgency: v })}
            />
          </Question>
        )}

        {step === 4 && (
          <Question
            title="Do you currently have any income?"
            sub="Even part-time, gig work, or benefits count."
          >
            <ChoiceGrid
              options={[
                { value: true, label: "Yes" },
                { value: false, label: "No" },
              ]}
              value={state.hasIncome}
              onChange={(v) => setState({ ...state, hasIncome: v })}
            />
          </Question>
        )}

        {error && (
          <p className="mt-6 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
            {error}
          </p>
        )}

        <div className="mt-10 flex items-center justify-between">
          <button
            type="button"
            onClick={back}
            disabled={step === 0 || submitting}
            className="inline-flex items-center gap-1.5 text-sm text-subtle transition-colors hover:text-text disabled:cursor-not-allowed disabled:opacity-30"
          >
            <ArrowLeft className="h-4 w-4" aria-hidden />
            Back
          </button>

          <button
            type="button"
            onClick={next}
            disabled={!canAdvance() || submitting}
            className="group inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-white shadow-cta transition-all hover:scale-[1.02] disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:scale-100"
          >
            {submitting
              ? "Finding matches…"
              : step === totalSteps - 1
                ? "Show my options"
                : "Continue"}
            {!submitting && (
              <ArrowRight
                className="h-4 w-4 transition-transform group-hover:translate-x-0.5"
                aria-hidden
              />
            )}
          </button>
        </div>
      </div>

      <p className="mt-6 text-center text-xs text-subtle">
        Your answers are never stored on our servers. They live in this browser
        session only.
      </p>
    </div>
  );
}

/* ------------------------- subcomponents ------------------------- */

function Question({
  title,
  sub,
  children,
}: {
  title: string;
  sub?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h2 className="font-serif text-3xl font-medium leading-tight tracking-tight text-text md:text-4xl">
        {title}
      </h2>
      {sub && <p className="mt-2 text-sm text-muted">{sub}</p>}
      <div className="mt-8">{children}</div>
    </div>
  );
}

function ChoiceGrid<T>({
  options,
  value,
  onChange,
}: {
  options: Array<{ value: T; label: string }>;
  value: T | null;
  onChange: (v: T) => void;
}) {
  return (
    <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
      {options.map((opt, i) => {
        const selected = opt.value === value;
        return (
          <button
            key={i}
            type="button"
            onClick={() => onChange(opt.value)}
            aria-pressed={selected}
            className={`rounded-xl border px-4 py-3.5 text-left text-sm transition-all ${
              selected
                ? "border-primary bg-primary/10 text-text"
                : "border-border bg-bg text-muted hover:border-primary/40 hover:text-text"
            }`}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}
