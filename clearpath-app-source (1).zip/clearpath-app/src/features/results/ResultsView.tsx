"use client";

import { ArrowRight, ExternalLink, Phone } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import type { MatchResponse, Program, QuizAnswers } from "@/types/program";

const categoryLabel: Record<string, string> = {
  cdfi: "Nonprofit Lender",
  credit_union: "Credit Union",
  government: "Government Assistance",
  community_fund: "Community Fund",
  employer_advance: "Employer Advance",
  faith_based: "Faith-Based Aid",
  utility: "Utility Hardship",
};

export function ResultsView() {
  const router = useRouter();
  const [data, setData] = useState<MatchResponse | null>(null);
  const [answers, setAnswers] = useState<QuizAnswers | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const raw = sessionStorage.getItem("clearpath:results");
    const ansRaw = sessionStorage.getItem("clearpath:answers");
    if (!raw || !ansRaw) {
      router.push("/quiz");
      return;
    }
    try {
      setData(JSON.parse(raw));
      setAnswers(JSON.parse(ansRaw));
    } catch {
      router.push("/quiz");
      return;
    }
    setLoaded(true);
  }, [router]);

  if (!loaded || !data || !answers) {
    return (
      <div className="mx-auto max-w-3xl px-6 py-24 text-center text-muted">
        Loading your matches…
      </div>
    );
  }

  const hasMatches = data.matches.length > 0;
  const list = hasMatches ? data.matches : (data.fallbackResources ?? []);

  return (
    <div className="mx-auto max-w-3xl px-6 py-16 md:py-20">
      <div className="mb-10">
        <p className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-accent">
          Your matches
        </p>
        <h1 className="font-serif text-4xl font-medium leading-tight tracking-tight text-text md:text-5xl">
          {hasMatches
            ? `We found ${data.matches.length} option${data.matches.length === 1 ? "" : "s"} for you.`
            : "We couldn't find a perfect match — but here's where to start."}
        </h1>
        <p className="mt-4 text-muted">
          {hasMatches
            ? "These programs serve your ZIP code and address what you told us. Click each one to learn more or apply directly."
            : "These two resources connect you with people in your community who can help find the right program."}
        </p>
      </div>

      <div className="space-y-4">
        {list.map((p) => (
          <ProgramCard key={p.id} program={p} />
        ))}
      </div>

      <div className="mt-12 flex flex-col items-center gap-4">
        <Link
          href="/quiz"
          className="text-sm text-subtle underline-offset-4 transition-colors hover:text-text hover:underline"
        >
          ← Start over with different answers
        </Link>
        <Link
          href="/"
          className="text-xs text-subtle transition-colors hover:text-text"
        >
          Back to ClearPath home
        </Link>
      </div>

      <p className="mt-12 rounded-xl border border-border bg-surface p-5 text-center text-xs text-subtle">
        ClearPath is not a lender and does not control eligibility or terms. Each
        program above is run by an independent organization. Always read the
        program's own terms before applying.
      </p>
    </div>
  );
}

function ProgramCard({ program }: { program: Program }) {
  const isPhone = program.action.type === "phone";
  return (
    <article className="rounded-2xl border border-border bg-surface p-6 transition-colors hover:border-primary/40">
      <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-accent">
        {categoryLabel[program.category] ?? program.category}
      </p>
      <h2 className="text-lg font-semibold text-text">{program.name}</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted">{program.description}</p>
      {program.eligibility && (
        <p className="mt-3 text-xs text-subtle">
          <span className="font-medium text-muted">Eligibility:</span>{" "}
          {program.eligibility}
        </p>
      )}
      <div className="mt-5">
        {isPhone ? (
          <a
            href={`tel:${program.action.value}`}
            className="group inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-white shadow-cta transition-all hover:scale-[1.02]"
          >
            <Phone className="h-4 w-4" aria-hidden />
            {program.action.label}
          </a>
        ) : (
          <a
            href={program.action.value}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-white shadow-cta transition-all hover:scale-[1.02]"
          >
            {program.action.label}
            <ExternalLink className="h-3.5 w-3.5" aria-hidden />
          </a>
        )}
      </div>
    </article>
  );
}
