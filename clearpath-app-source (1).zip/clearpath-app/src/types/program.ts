/**
 * Domain type for a single financial-help program in our database.
 */

export type ProgramCategory =
  | "cdfi"
  | "credit_union"
  | "government"
  | "community_fund"
  | "employer_advance"
  | "faith_based"
  | "utility";

export type NeedType =
  | "rent"
  | "utilities"
  | "food"
  | "medical"
  | "car_repair"
  | "other";

export interface Program {
  /** stable id, used as React key + analytics */
  id: string;
  name: string;
  category: ProgramCategory;
  /** one-line plain-English description */
  description: string;
  /** which needs the program addresses */
  helpsWith: NeedType[];
  /**
   * coverage:
   *  - "national" → available everywhere in the US
   *  - string[]  → list of two-letter US state codes
   */
  coverage: "national" | string[];
  /** how the user is asked to act */
  action: {
    type: "url" | "phone";
    value: string;
    label: string;
  };
  /** soft eligibility hints (free text, shown in the card) */
  eligibility?: string;
}

export interface QuizAnswers {
  zip: string;
  need: NeedType;
  amountNeeded: "<200" | "200-500" | "500-1000" | "1000+";
  urgency: "today" | "this_week" | "this_month";
  hasIncome: boolean;
}

export interface MatchResponse {
  matches: Program[];
  /** total programs in the database we considered */
  considered: number;
  /** when no matches found */
  fallbackResources?: Program[];
}
