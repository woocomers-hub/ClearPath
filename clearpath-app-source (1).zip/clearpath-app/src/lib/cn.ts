/**
 * Tiny className combiner. Filters out falsy values so you can write:
 *   cn("base", isActive && "active", maybeClass)
 */
export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}
