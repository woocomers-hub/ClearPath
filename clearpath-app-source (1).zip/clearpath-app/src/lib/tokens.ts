/**
 * Design tokens — the single source of truth for every color, font,
 * spacing decision in the ClearPath product.
 *
 * Rule: NEVER hardcode a hex value or font family in a component.
 * If you need a new value, add it here first.
 */

export const tokens = {
  color: {
    /* surfaces */
    bg: "#0B0F14",
    surface: "#111720",
    surfaceAlt: "#1A2230",
    border: "#1F2937",

    /* text */
    text: "#E8EDF2",
    muted: "#94A3B8",
    subtle: "#64748B",

    /* brand */
    primary: "#3B82F6",
    accent: "#7DD3FC",

    /* status */
    success: "#34D399",
  },
  font: {
    sans: "Inter, ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
    serif: "'Cormorant Garamond', 'Playfair Display', Georgia, serif",
  },
  radius: {
    pill: "9999px",
    lg: "1rem",
    xl: "1.25rem",
  },
} as const;

export type Tokens = typeof tokens;
