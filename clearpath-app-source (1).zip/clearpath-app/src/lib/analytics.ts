/**
 * Privacy-first analytics shim. Sends events to Plausible if configured,
 * otherwise no-ops. We never collect PII, never fingerprint, never set
 * tracking cookies.
 */

type EventProps = Record<string, string | number | boolean>;

declare global {
  interface Window {
    plausible?: (event: string, opts?: { props?: EventProps }) => void;
  }
}

export function trackEvent(name: string, props?: EventProps): void {
  if (typeof window === "undefined") return;
  if (typeof window.plausible !== "function") return;
  window.plausible(name, props ? { props } : undefined);
}
