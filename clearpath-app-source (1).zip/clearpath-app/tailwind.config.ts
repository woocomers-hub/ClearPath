import type { Config } from "tailwindcss";
import { tokens } from "./src/lib/tokens";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: tokens.color.bg,
        surface: tokens.color.surface,
        surfaceAlt: tokens.color.surfaceAlt,
        border: tokens.color.border,
        text: tokens.color.text,
        muted: tokens.color.muted,
        subtle: tokens.color.subtle,
        primary: tokens.color.primary,
        accent: tokens.color.accent,
        success: tokens.color.success,
      },
      fontFamily: {
        sans: ["var(--font-sans)", "ui-sans-serif", "system-ui", "sans-serif"],
        serif: ["var(--font-serif)", "Georgia", "serif"],
      },
      maxWidth: {
        prose: "65ch",
      },
      boxShadow: {
        cta: "0 8px 30px rgba(59,130,246,0.35)",
      },
    },
  },
  plugins: [],
};

export default config;
